void negatyw(pgm *obraz);
void progowanie(pgm *obraz, int prog);
void splot(pgm *obraz, int splot[3][3]);
void konturowanie(pgm *obraz);
int zapisz(FILE *p, pgm *obraz);
