
int negatyw(pgm *obraz);
int progczerni(pgm *obraz,int prog);
int rozhist(pgm *obraz);
int konturowanie(pgm *obraz);